# L06 AI-Driven Data Analytics for IIoT

This repository contains the code for the IIoT Time Series Forecasting Lab. The objective is to forecast temperature data from an IoT sensor using time-series forecasting techniques.

## Structure

L06_AI_Driven_Data_Analytics_IIoT/
├── README.md
├── requirements.txt
├── data/
│   └── IOT-temp.csv
├── notebooks/
│   └── L06_SubmitterName_ITAI3377.ipynb
└── src/
    ├── data_preparation.py
    ├── model_training.py
    ├── feature_engineering.py
    ├── evaluation.py
    ├── generative_model.py
    └── main.py

## Instructions

1. **Data Preparation:** 
   - Load and preprocess the dataset.
   - Inspect for missing values, outliers, and perform normalization if required.

2. **Model Training:**
   - Use Nixtla's AutoML tools to select and train a forecasting model.
   - Document the model selection process.

3. **Feature Engineering:**
   - Use automated feature extraction and add custom features.

4. **Evaluation:**
   - Evaluate the model using metrics like MAE, MSE, and MASE.
   - Perform rolling-origin cross-validation.

5. **Generative Modeling:**
   - Use a Variational Autoencoder (VAE) to generate synthetic data to augment the training set.

6. **Execution:**
   - Run the main pipeline using `src/main.py`.

## Dependencies

Install the required libraries using:


## Submission

- Final report: `L06_SubmitterName_ITAI3377.pdf`
- Code: This repository including all Python scripts and the Jupyter Notebook.
