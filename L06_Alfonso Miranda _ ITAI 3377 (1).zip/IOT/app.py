#!/usr/bin/env python3

import argparse
import os
import logging
from datetime import datetime, timedelta
import pandas as pd
import matplotlib.pyplot as plt

from src.data_preparation import load_and_preprocess_data
from src.feature_engineering import add_custom_features
from src.model_training import train_forecasting_model, train_and_predict
from src.evaluation import evaluate_model
from src.generate_model import augment_data_with_vae
from src.cross_validation import rolling_origin_cv

# -------------------------
# Setup Logging
# -------------------------
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Create file handler to write logs to 'pipeline.log'
log_filename = f"pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
file_handler = logging.FileHandler(log_filename)
file_handler.setLevel(logging.INFO)

# Create console handler for output to terminal
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# Define a log format
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# Add handlers to the logger
logger.addHandler(file_handler)
logger.addHandler(console_handler)


def plot_forecast(test_df, forecast_df):
    """
    Plots the actual test values against the forecasted values.
    Assumes test_df contains 'timestamp' and 'temperature',
    and forecast_df contains 'ds' (datetime) and 'TimeGPT' (forecasted temperature).
    """
    forecast_df['ds'] = pd.to_datetime(forecast_df['ds'])
    
    plt.figure(figsize=(12, 6))
    plt.plot(test_df['timestamp'], test_df['temperature'], label='Actual', marker='o')
    plt.plot(forecast_df['ds'], forecast_df['TimeGPT'], label='Forecast', linestyle='--', marker='x')
    plt.xlabel("Time")
    plt.ylabel("Temperature")
    plt.title("Actual vs Forecasted Temperature")
    plt.legend()
    plt.show()


def plot_train_test_split(full_df, train_df, test_df):
    """
    Plots the full time series with training and testing splits.
    """
    plt.figure(figsize=(14, 6))
    plt.plot(full_df['timestamp'], full_df['temperature'], label='Full Data', color='gray', alpha=0.5)
    plt.plot(train_df['timestamp'], train_df['temperature'], label='Training Data', color='blue')
    plt.plot(test_df['timestamp'], test_df['temperature'], label='Test Data', color='red')
    plt.xlabel("Time")
    plt.ylabel("Temperature")
    plt.title("Full Time Series with Training/Test Split")
    plt.legend()
    plt.show()


def plot_forecast_residuals(test_df, forecast_df):
    """
    Plots the forecast residuals (Actual - Forecast).
    """
    forecast_df['ds'] = pd.to_datetime(forecast_df['ds'])
    merged = pd.merge(test_df, forecast_df[['ds', 'TimeGPT']], left_on='timestamp', right_on='ds', how='inner')
    merged['residual'] = merged['temperature'] - merged['TimeGPT']
    
    plt.figure(figsize=(12, 6))
    plt.plot(merged['timestamp'], merged['residual'], marker='o', linestyle='-', color='purple')
    plt.xlabel("Time")
    plt.ylabel("Residual (Actual - Forecast)")
    plt.title("Forecast Residuals Over Time")
    plt.axhline(0, color='black', linestyle='--')
    plt.show()


def plot_error_distribution(test_df, forecast_df):
    """
    Plots a histogram of forecast errors.
    """
    forecast_df['ds'] = pd.to_datetime(forecast_df['ds'])
    merged = pd.merge(test_df, forecast_df[['ds', 'TimeGPT']], left_on='timestamp', right_on='ds', how='inner')
    merged['error'] = merged['temperature'] - merged['TimeGPT']
    
    plt.figure(figsize=(10, 5))
    plt.hist(merged['error'], bins=30, color='orange', edgecolor='black')
    plt.xlabel("Forecast Error")
    plt.ylabel("Frequency")
    plt.title("Histogram of Forecast Errors")
    plt.show()


def plot_rolling_statistics(df, window=30):
    """
    Plots the rolling mean and rolling standard deviation of the temperature.
    """
    df_copy = df.copy()
    df_copy['rolling_mean'] = df_copy['temperature'].rolling(window=window).mean()
    df_copy['rolling_std'] = df_copy['temperature'].rolling(window=window).std()
    
    plt.figure(figsize=(14, 6))
    plt.plot(df_copy['timestamp'], df_copy['temperature'], label='Temperature', alpha=0.5)
    plt.plot(df_copy['timestamp'], df_copy['rolling_mean'], label=f'{window}-point Rolling Mean', color='red')
    plt.fill_between(df_copy['timestamp'], 
                     df_copy['rolling_mean'] - df_copy['rolling_std'], 
                     df_copy['rolling_mean'] + df_copy['rolling_std'], 
                     color='red', alpha=0.2, label=f'{window}-point Rolling Std')
    plt.xlabel("Time")
    plt.ylabel("Temperature")
    plt.title("Rolling Statistics")
    plt.legend()
    plt.show()


def run_pipeline(data_path, epochs, batch_size, augment):
    """
    Runs the entire IIoT temperature forecasting pipeline:
      1. Data Loading & Preprocessing
      2. Feature Engineering
      3. Model Training & Forecasting
      4. Model Evaluation
      5. Rolling-Origin Cross-Validation
      6. (Optional) Generative Modeling with VAE and Re-training with Augmented Data
    """
    logger.info("=== PIPELINE START ===")
    logger.info("Step 1: Data Loading & Preprocessing")
    df = load_and_preprocess_data(data_path)
    logger.info(f"Data loaded. Shape: {df.shape}")

    logger.info("Step 2: Feature Engineering")
    df = add_custom_features(df)
    logger.info("Custom features added. Sample:\n%s", df.head())

    # Split data into training and test sets for plotting and model training.
    train_size = int(0.8 * len(df))
    train = df.iloc[:train_size].copy()
    test = df.iloc[train_size:].copy()

    logger.info("Plotting Train/Test Split")
    plot_train_test_split(df, train, test)

    logger.info("Step 3: Model Training & Forecasting")
    model, forecast, test_model = train_forecasting_model(df)
    logger.info("Model trained. Forecast sample:\n%s", forecast.head())

    logger.info("Plotting Forecast vs Actual")
    plot_forecast(test_model, forecast)

    logger.info("Step 4: Model Evaluation")
    eval_results = evaluate_model(test_model, forecast)
    logger.info("Evaluation Results: %s", eval_results)

    logger.info("Plotting Forecast Residuals")
    plot_forecast_residuals(test_model, forecast)

    logger.info("Plotting Error Distribution")
    plot_error_distribution(test_model, forecast)

    logger.info("Plotting Rolling Statistics")
    plot_rolling_statistics(df, window=30)

    # Save forecast to CSV (optional)
    forecast.to_csv("forecast_output.csv", index=False)
    logger.info("Forecast saved to 'forecast_output.csv'")

    logger.info("Step 5: Rolling-Origin Cross-Validation")
    cv_metrics = rolling_origin_cv(df)
    logger.info("Rolling-Origin CV Metrics: %s", cv_metrics)

    if augment:
        logger.info("Step 6: Generative Modeling (VAE) and Re-training with Augmented Data")
        logger.info("Training VAE and generating synthetic data...")
        synthetic_df = augment_data_with_vae(df, epochs=epochs, batch_size=batch_size)
        logger.info("Synthetic Data Sample:\n%s", synthetic_df.head())
        
        # Create timestamps for synthetic data by extrapolating from the last timestamp of original data
        last_timestamp = df['timestamp'].max()
        synthetic_timestamps = [last_timestamp + timedelta(minutes=i+1) for i in range(len(synthetic_df))]
        synthetic_df['timestamp'] = synthetic_timestamps
        
        # For synthetic data, add missing feature columns (simple assignment)
        synthetic_df['rolling_mean_temp'] = synthetic_df['temperature']
        synthetic_df['hour'] = [ts.hour for ts in synthetic_df['timestamp']]
        
        # Combine original and synthetic data
        augmented_df = pd.concat([df, synthetic_df], ignore_index=True)
        augmented_df = augmented_df.sort_values('timestamp')
        logger.info("Augmented Data Shape: %s", augmented_df.shape)
        
        logger.info("Re-training forecasting model on augmented data...")
        model_aug, forecast_aug, test_aug = train_forecasting_model(augmented_df)
        eval_results_aug = evaluate_model(test_aug, forecast_aug)
        logger.info("Evaluation Results after Augmentation: %s", eval_results_aug)
        
        logger.info("Plotting Forecast vs Actual for Augmented Model")
        plot_forecast(test_aug, forecast_aug)
    else:
        logger.info("Skipping VAE-based augmentation as per user input.")

    logger.info("=== PIPELINE COMPLETE ===")
    logger.info("A detailed log of this run is saved to '%s'", log_filename)


def main():
    parser = argparse.ArgumentParser(description="Run IIoT temperature forecasting pipeline with optional data augmentation.")
    parser.add_argument("--data", type=str, default="data/IOT-temp.csv", help="Path to the IoT temperature CSV file.")
    parser.add_argument("--vae_epochs", type=int, default=10, help="Number of training epochs for VAE.")
    parser.add_argument("--vae_batch_size", type=int, default=32, help="Batch size for VAE training.")
    parser.add_argument("--augment", action="store_true", help="Use this flag to enable VAE-based data augmentation and re-training.")

    args = parser.parse_args()
    data_path = args.data
    if not os.path.exists(data_path):
        logger.error("Data file not found: %s", data_path)
        raise FileNotFoundError(f"Data file not found: {data_path}")

    run_pipeline(data_path=data_path, epochs=args.vae_epochs, batch_size=args.vae_batch_size, augment=args.augment)


if __name__ == "__main__":
    main()
