# src/data_preparation.py
import pandas as pd
import matplotlib.pyplot as plt

def load_and_preprocess_data(filepath, timestamp_col=None, temperature_col=None):
    """
    Loads the IoT temperature dataset from a CSV file, inspects and preprocesses the data.
    
    Steps:
      1. Detects common names for timestamp and temperature columns and renames them to
         'timestamp' and 'temperature' respectively.
      2. Converts the timestamp column to datetime using dayfirst=True.
      3. Aggregates duplicate timestamps by taking the mean of temperature.
      4. Infers the frequency of the time index. If inference fails, computes the median 
         difference and chooses a frequency.
      5. Resamples the data to a regular frequency (forward filling missing values).
      6. Plots and saves a figure of temperature vs. time.
    """
    # Load a preview of the CSV to detect column names
    preview = pd.read_csv(filepath, nrows=5)
    preview.columns = preview.columns.str.strip()

    # Detect timestamp column if not provided
    if timestamp_col is None:
        common_time_names = ['timestamp', 'noted_date', 'date', 'time']
        ts_cols = [col for col in preview.columns if col.lower() in common_time_names]
        if ts_cols:
            timestamp_col = ts_cols[0]
        else:
            raise ValueError("CSV file must contain a column related to time (e.g., 'timestamp', 'noted_date').")

    # Detect temperature column if not provided
    if temperature_col is None:
        common_temp_names = ['temperature', 'temp']
        temp_cols = [col for col in preview.columns if col.lower() in common_temp_names]
        if temp_cols:
            temperature_col = temp_cols[0]
        else:
            raise ValueError("CSV file must contain a column for temperature (e.g., 'temp' or 'temperature').")

    # Load the full CSV without parsing dates
    df = pd.read_csv(filepath)
    df.columns = df.columns.str.strip()

    # Rename columns to standard names
    if timestamp_col != 'timestamp':
        df = df.rename(columns={timestamp_col: 'timestamp'})
    if temperature_col != 'temperature':
        df = df.rename(columns={temperature_col: 'temperature'})

    # Convert 'timestamp' column to datetime using dayfirst=True
    df['timestamp'] = pd.to_datetime(df['timestamp'], dayfirst=True)

    # Aggregate duplicate timestamps by taking the mean temperature
    df = df.groupby('timestamp', as_index=False).agg({'temperature': 'mean'})

    # Sort the data by timestamp
    df = df.sort_values('timestamp')

    # Set timestamp as the index and attempt to infer frequency
    df = df.set_index('timestamp')
    freq = pd.infer_freq(df.index)
    if freq is None:
        # Compute median time difference (in seconds) to choose a frequency
        diffs = df.index.to_series().diff().dropna().dt.total_seconds()
        median_diff = diffs.median()
        if median_diff < 60:
            freq = 'S'  # seconds
        elif median_diff < 3600:
            freq = 'T'  # minutes
        elif median_diff < 86400:
            freq = 'H'  # hourly
        else:
            freq = 'D'  # daily

    # Resample to a regular frequency using forward fill for missing values
    df = df.asfreq(freq, method='ffill').reset_index()

    # Plot the temperature data and save the figure
    plt.figure(figsize=(10, 4))
    plt.plot(df['timestamp'], df['temperature'], label='Temperature')
    plt.xlabel('Time')
    plt.ylabel('Temperature')
    plt.title('IoT Temperature Data')
    plt.legend()
    plt.savefig("data_preprocessing_plot.png")
    plt.close()

    return df

if __name__ == "__main__":
    df = load_and_preprocess_data("../data/IOT-temp.csv")
    print(df.head())
