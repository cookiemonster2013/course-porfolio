# src/main.py
from data_preparation import load_and_preprocess_data
from model_training import train_forecasting_model
from feature_engineering import add_custom_features
from evaluation import evaluate_model
from generative_model import augment_data_with_vae

def main():
    # Load and preprocess data
    df = load_and_preprocess_data("../data/IOT-temp.csv")
    
    # Feature Engineering: add custom features
    df = add_custom_features(df)
    
    # Train forecasting model using Nixtla AutoML
    model, forecast, test = train_forecasting_model(df)
    
    # Evaluate model performance
    evaluation_results = evaluate_model(test, forecast)
    print("Evaluation Results:")
    print(evaluation_results)
    
    # Generate synthetic data using VAE for data augmentation
    synthetic_df = augment_data_with_vae(df)
    print("Synthetic Data Sample:")
    print(synthetic_df.head())
    
    # Optionally, you could re-train the model using the augmented dataset
    
if __name__ == "__main__":
    main()
