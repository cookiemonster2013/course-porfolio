# src/cross_validation.py
import pandas as pd
import numpy as np
from src.model_training import train_and_predict
from src.evaluation import evaluate_model
import logging

def rolling_origin_cv(df, initial_train_ratio=0.5, n_splits=5):
    """
    Performs rolling-origin cross validation on the given dataframe.
    
    Parameters:
      df: DataFrame sorted by timestamp.
      initial_train_ratio: The fraction of data to use for the initial training set.
      n_splits: Number of splits for cross validation.
      
    Returns:
      A list of evaluation metric dictionaries for each split.
    """
    n = len(df)
    initial_train_size = int(n * initial_train_ratio)
    split_size = (n - initial_train_size) // n_splits
    metrics_list = []
    
    for i in range(n_splits):
        train_end = initial_train_size + i * split_size
        test_end = train_end + split_size
        if test_end > n:
            test_end = n
        train_df = df.iloc[:train_end].copy()
        test_df = df.iloc[train_end:test_end].copy()
        
        if len(test_df) == 0:
            break
        
        model, forecast = train_and_predict(train_df, test_df)
        metrics = evaluate_model(test_df, forecast)
        metrics_list.append(metrics)
        
        logging.info(f"CV Split {i+1}: Train Size = {len(train_df)}, Test Size = {len(test_df)}, Metrics = {metrics}")
    
    return metrics_list

if __name__ == "__main__":
    import pandas as pd
    from src.data_preparation import load_and_preprocess_data
    df = load_and_preprocess_data("../data/IOT-temp.csv")
    metrics = rolling_origin_cv(df)
    print("Rolling-Origin CV Metrics:", metrics)
