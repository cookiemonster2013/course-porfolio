# src/generative_model.py
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras import layers

def build_vae(timesteps, features, latent_dim=2):
    """
    Builds and returns a Variational Autoencoder (VAE) for time-series data.
    """
    # Encoder
    encoder_inputs = tf.keras.Input(shape=(timesteps, features))
    x = layers.LSTM(64, return_sequences=False)(encoder_inputs)
    z_mean = layers.Dense(latent_dim, name='z_mean')(x)
    z_log_var = layers.Dense(latent_dim, name='z_log_var')(x)
    
    def sampling(args):
        z_mean, z_log_var = args
        epsilon = tf.random.normal(shape=(tf.shape(z_mean)[0], latent_dim))
        return z_mean + tf.exp(0.5 * z_log_var) * epsilon
    
    z = layers.Lambda(sampling, name='z')([z_mean, z_log_var])
    encoder = tf.keras.Model(encoder_inputs, [z_mean, z_log_var, z], name='encoder')
    
    # Decoder
    latent_inputs = tf.keras.Input(shape=(latent_dim,))
    x = layers.RepeatVector(timesteps)(latent_inputs)
    x = layers.LSTM(64, return_sequences=True)(x)
    decoder_outputs = layers.TimeDistributed(layers.Dense(features))(x)
    decoder = tf.keras.Model(latent_inputs, decoder_outputs, name='decoder')
    
    # VAE Model
    outputs = decoder(encoder(encoder_inputs)[2])
    vae = tf.keras.Model(encoder_inputs, outputs, name='vae')
    
    # Compute VAE loss
    reconstruction_loss = tf.keras.losses.mean_squared_error(encoder_inputs, outputs)
    reconstruction_loss = tf.reduce_mean(reconstruction_loss)
    kl_loss = -0.5 * tf.reduce_mean(1 + z_log_var - tf.square(z_mean) - tf.exp(z_log_var))
    vae_loss = reconstruction_loss + kl_loss
    vae.add_loss(vae_loss)
    
    vae.compile(optimizer='adam')
    return vae, encoder, decoder

def augment_data_with_vae(df, epochs=50, batch_size=32):
    """
    Trains a VAE on the temperature data and generates synthetic time-series samples.
    """
    # Parameters for sequence creation
    timesteps = 10  # Example sequence length
    features = 1    # Using only temperature for now
    
    # Create sequences from the temperature data
    data = df['temperature'].values
    sequences = []
    for i in range(len(data) - timesteps):
        sequences.append(data[i:i+timesteps])
    sequences = np.array(sequences)
    sequences = sequences.reshape(-1, timesteps, features)
    
    # Build and train the VAE model
    vae, encoder, decoder = build_vae(timesteps, features)
    vae.fit(sequences, epochs=epochs, batch_size=batch_size, verbose=0)
    
    # Generate synthetic data by sampling from the latent space
    num_samples = len(sequences)
    latent_dim = encoder.get_layer('z_mean').output_shape[-1]
    synthetic_latent = np.random.normal(size=(num_samples, latent_dim))
    synthetic_sequences = decoder.predict(synthetic_latent)
    
    # Reshape and convert synthetic sequences to a DataFrame
    synthetic_data = synthetic_sequences.reshape(-1)
    synthetic_df = pd.DataFrame(synthetic_data, columns=['temperature'])
    
    return synthetic_df

if __name__ == "__main__":
    # For testing purposes
    import pandas as pd
    df = pd.read_csv("../data/IOT-temp.csv", parse_dates=['timestamp'])
    synthetic_df = augment_data_with_vae(df, epochs=10)
    print(synthetic_df.head())
