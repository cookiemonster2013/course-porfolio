# src/feature_engineering.py
import pandas as pd

def add_custom_features(df):
    """
    Adds custom features to the dataframe:
    1. Rolling mean temperature over a window of 5 measurements.
    2. Hour of day extracted from the timestamp.
    """
    df = df.copy()
    
    # Custom Feature 1: Rolling Mean Temperature
    df['rolling_mean_temp'] = df['temperature'].rolling(window=5, min_periods=1).mean()
    
    # Custom Feature 2: Hour of Day (for capturing diurnal patterns)
    df['hour'] = df['timestamp'].dt.hour
    
    return df

if __name__ == "__main__":
    # For testing purposes
    from data_preparation import load_and_preprocess_data
    df = load_and_preprocess_data("../data/IOT-temp.csv")
    df_fe = add_custom_features(df)
    print(df_fe.head())
