# src/evaluation.py
from sklearn.metrics import mean_absolute_error, mean_squared_error

def evaluate_model(test_df, forecast):
    """
    Evaluates the forecasting model using MAE and MSE.
    
    Parameters:
      - test_df: DataFrame containing the true values (with column 'temperature').
      - forecast: DataFrame containing the forecasted values.
      
    The Nixtla forecast output typically contains a column named "TimeGPT" representing
    the point forecasts. If available, it is used; otherwise, it falls back to a column
    named "temperature" or the forecast's values directly.
    
    Returns:
      A dictionary with evaluation metrics.
    """
    true_values = test_df['temperature'].values
    
    # Try to use the 'TimeGPT' column from the forecast if available.
    if 'TimeGPT' in forecast.columns:
        predicted_values = forecast['TimeGPT'].values
    elif 'temperature' in forecast.columns:
        predicted_values = forecast['temperature'].values
    else:
        predicted_values = forecast.values
    
    mae = mean_absolute_error(true_values, predicted_values)
    mse = mean_squared_error(true_values, predicted_values)
    
    results = {
        'MAE': mae,
        'MSE': mse
    }
    return results

if __name__ == "__main__":
    # Example usage with dummy data:
    import pandas as pd
    test_df = pd.DataFrame({'temperature': [31, 32, 33]})
    # Dummy forecast: using Nixtla-like output with 'TimeGPT' column.
    forecast = pd.DataFrame({
        'ds': ['2018-11-11 18:38:00', '2018-11-11 18:39:00', '2018-11-11 18:40:00'],
        'TimeGPT': [30.5, 32.0, 33.5],
        'TimeGPT-hi-80': [31.5, 33.0, 34.5],
        'TimeGPT-hi-90': [32.0, 33.5, 35.0],
        'TimeGPT-lo-80': [30.0, 31.5, 33.0],
        'TimeGPT-lo-90': [29.5, 31.0, 32.5]
    })
    results = evaluate_model(test_df, forecast)
    print("Evaluation Results:", results)
