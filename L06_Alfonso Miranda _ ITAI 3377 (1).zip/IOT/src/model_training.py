# src/model_training.py
import pandas as pd
from nixtla import NixtlaClient  # Ensure the nixtla package is installed
from sklearn.model_selection import train_test_split

# 1. Instantiate the NixtlaClient with your API Key
nixtla_client = NixtlaClient(api_key='nixak-QVVL2ZPPvriFrjAXB5L9wIQsLrA89zD9p7cXevyCW8M6jYNeZeisIaXuU3IRG7ovY3NAzHZQhNiQ3BHl')

class NixtlaModel:
    """
    A wrapper model that uses NixtlaClient to forecast, including exogenous features.
    """
    def __init__(self, train_df, level=[80, 90]):
        self.train_df = train_df
        self.level = level

    def predict(self, test_df):
        """
        Forecast for the test set period. The forecast horizon is determined by the number of rows in test_df.
        Exogenous features 'rolling_mean_temp' and 'hour' are declared for use.
        """
        horizon = len(test_df)
        # Rename columns to meet Nixtla's expected format:
        # 'ds' for datetime and 'y' for the target.
        df_train = self.train_df.copy().rename(columns={'timestamp': 'ds', 'temperature': 'y'})
        # Call NixtlaClient.forecast, providing the list of exogenous features.
        fcst_df = nixtla_client.forecast(
            df_train,
            h=horizon,
            level=self.level,
            hist_exog_list=['rolling_mean_temp', 'hour']
        )
        return fcst_df

def train_forecasting_model(df):
    """
    Splits the data into training and testing sets and trains a forecasting model using Nixtla.
    Returns the trained model, forecast for the test set, and the test set.
    """
    # 80/20 train-test split
    train_size = int(0.8 * len(df))
    train = df.iloc[:train_size].copy()
    test = df.iloc[train_size:].copy()
    
    # Instantiate the Nixtla forecasting model with training data.
    model = NixtlaModel(train, level=[80, 90])
    
    # Forecast for the test set period
    forecast = model.predict(test)
    
    return model, forecast, test

def train_and_predict(train_df, test_df):
    """
    Trains a forecasting model on provided training data and predicts on test data.
    """
    model = NixtlaModel(train_df, level=[80, 90])
    forecast = model.predict(test_df)
    return model, forecast

if __name__ == "__main__":
    # For testing purposes:
    from data_preparation import load_and_preprocess_data
    df = load_and_preprocess_data("../data/IOT-temp.csv")
    model, forecast, test = train_forecasting_model(df)
    print("Forecast:")
    print(forecast)
